//
// Created by amichai on 12/01/19.
//

#include "Pareto.h"
